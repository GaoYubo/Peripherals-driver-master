#ifndef __GPIO_CONF_H
#define __GPIO_CONF_H

#include "stm32f10x.h"

void GPIO_Configuration(void);

#endif 
