#include "sys.h"

static void sysFlashLedTask(void *pvParameters);
static void sys_flash_led(void);


void system_init(void)
{
    GPIO_Configuration();
    xTaskCreate(sysFlashLedTask,(const char*)"sysFlashLedTask",4,NULL,4,NULL);
}


/**
  * @brief  sysFlashLedTask
  * @param  None
  * @retval None
  */
static void sysFlashLedTask(void *pvParameters)
{
    for(;;)
    {
        sys_flash_led();
        vTaskDelay(100);
    }
}

/**
  * @brief  sys_flash_led
  * @param  None
  * @retval None
  */
static void sys_flash_led(void)
{
    if(GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_1))
        GPIO_ResetBits(GPIOB,GPIO_Pin_1);
    else
        GPIO_SetBits(GPIOB,GPIO_Pin_1);
        
        
}
