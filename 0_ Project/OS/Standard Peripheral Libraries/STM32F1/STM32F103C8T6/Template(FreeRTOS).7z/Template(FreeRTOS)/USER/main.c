#include "sys.h"

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    system_init();
    vTaskStartScheduler();
    for(;;);
}
